import tkinter as tk
from tkinter import messagebox
import torch
from torchvision import transforms
from PIL import Image, ImageDraw, ImageTk
from cnn import CNN

MODEL_PATH = 'QCNN_for_MNIST.pth'

model = CNN()
model.load_state_dict(torch.load(MODEL_PATH, map_location=torch.device('cpu')))
model.eval()

transform = transforms.Compose([
    transforms.Resize((28, 28)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

BG_COLOR = "#ECEFF1"
BUTTON_COLOR = "#607D8B"
TEXT_COLOR = "#FFFFFF"
FONT_STYLE = "Helvetica 12 bold"

class DrawingCanvas(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.last_x, self.last_y = None, None
        self.bind("<B1-Motion>", self.paint)
        self.bind("<ButtonRelease-1>", self.reset)

    def paint(self, event):
        x, y = event.x, event.y
        if self.last_x and self.last_y:
            self.create_line(self.last_x, self.last_y, x, y, width=8, fill="black", capstyle=tk.ROUND, smooth=tk.TRUE)
        self.last_x, self.last_y = x, y

    def reset(self, event):
        self.last_x, self.last_y = None, None

    def clear(self):
        self.delete("all")

    def get_image(self):
        img = Image.new("L", (self.winfo_width(), self.winfo_height()), "white")
        draw = ImageDraw.Draw(img)
        for item in self.find_withtag('all'):
            x0, y0, x1, y1 = self.coords(item)
            draw.line([x0, y0, x1, y1], fill="black", width=8)
        img_resized = img.resize((28, 28), Image.LANCZOS)
        return img_resized.convert('L')

root = tk.Tk()
root.title("手写数字识别")
root.configure(bg=BG_COLOR)

canvas = DrawingCanvas(root, width=280, height=280, bg="white", highlightthickness=2, highlightbackground="#546E7A")
canvas.pack(pady=10, padx=20)

result_label = tk.Label(root, text="识别的数字: ", bg=BG_COLOR, font=FONT_STYLE)
result_label.pack(pady=5)

processed_img_label = tk.Label(root, bg=BG_COLOR)
processed_img_label.pack(pady=5)

def predict_image():
    image = canvas.get_image()
    input_tensor = transform(image).unsqueeze(0)

    img_tk = ImageTk.PhotoImage(image.resize((56, 56)).convert('RGB'))
    processed_img_label.configure(image=img_tk)
    processed_img_label.image = img_tk

    with torch.no_grad():
        output = model(input_tensor)
    _, predicted_class = torch.max(output, 1)
    result = predicted_class.item()

    result_label.config(text=f"预测的数字: {result}")
    messagebox.showinfo("预测的结果", f"识别的数字: {result}")

frame = tk.Frame(root, bg=BG_COLOR)
frame.pack(pady=10)

clear_button = tk.Button(frame, text="清空", width=10, command=canvas.clear, bg=BUTTON_COLOR, fg=TEXT_COLOR, font=FONT_STYLE)
clear_button.grid(row=0, column=0, padx=10)

predict_button = tk.Button(frame, text="识别", width=10, command=predict_image, bg=BUTTON_COLOR, fg=TEXT_COLOR, font=FONT_STYLE)
predict_button.grid(row=0, column=1, padx=10)

root.mainloop()
