# test.py - 测试模块
import torch
import torch.nn as nn
from qcnn_model import QCNN
from data_loader import get_data_loaders

def test_qcnn():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = QCNN().to(device)
    model.load_state_dict(torch.load("qcnn_model.pth", map_location=device))
    model.eval()

    _, test_loader = get_data_loaders(batch_size=32)
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    print(f'Test Accuracy: {100 * correct / total:.2f}%')


test_qcnn()
