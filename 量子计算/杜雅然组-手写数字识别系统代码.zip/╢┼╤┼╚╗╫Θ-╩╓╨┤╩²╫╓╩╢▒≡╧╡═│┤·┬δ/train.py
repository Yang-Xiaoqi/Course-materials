import torch
import torch.nn as nn
import torch.optim as optim
from qcnn_model import QCNN
from data_loader import get_data_loaders

def train_qcnn(num_epochs=10, learning_rate=0.001):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = QCNN().to(device)
    train_loader, _ = get_data_loaders(batch_size=32)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        print(f"Epoch {epoch+1}/{num_epochs}, Loss: {running_loss/len(train_loader):.4f}")

    torch.save(model.state_dict(), "qcnn_model.pth")
    print("Training complete. Model saved as 'qcnn_model.pth'")

train_qcnn()
