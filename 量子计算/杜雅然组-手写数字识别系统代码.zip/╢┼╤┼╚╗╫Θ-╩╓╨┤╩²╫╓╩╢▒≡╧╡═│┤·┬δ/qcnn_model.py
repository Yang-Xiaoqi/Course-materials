import torch
import torch.nn as nn
import torch.nn.functional as F
from qiskit import QuantumCircuit, Aer, execute


class QuantumConvLayer(nn.Module):
    def __init__(self):
        super(QuantumConvLayer, self).__init__()
        self.num_qubits = 4  # 使用4个量子比特

        self.rx_params = nn.Parameter(torch.randn(self.num_qubits))
        self.ry_params = nn.Parameter(torch.randn(self.num_qubits))
        self.rz_params = nn.Parameter(torch.randn(self.num_qubits))

    def quantum_circuit(self, data):
        """使用4个量子比特 + RX、RY、RZ、CNOT 的电路设计"""
        qc = QuantumCircuit(self.num_qubits)

        # 数据编码 (RX + RY + RZ 编码)
        for i in range(self.num_qubits):
            qc.rx(self.rx_params[i], i)
            qc.ry(self.ry_params[i], i)
            qc.rz(self.rz_params[i], i)

        # 纠缠层 (CNOT 门)
        qc.cx(0, 1)
        qc.cx(1, 2)
        qc.cx(2, 3)
        qc.cx(3, 0)

        qc.measure_all()
        return qc

    def forward(self, x):
        batch_size, _, height, width = x.size()
        output = []

        for i in range(0, height, 2):
            for j in range(0, width, 2):
                patch = x[:, :, i:i + 2, j:j + 2]
                patch = patch.flatten(1)

                simulator = Aer.get_backend('aer_simulator')
                patch_output = []

                for data in patch:
                    circuit = self.quantum_circuit(data.tolist()[:4])
                    job = execute(circuit, simulator, shots=1024)
                    result = job.result().get_counts()

                    output_value = sum(int(key, 2) * count for key, count in result.items()) / 1024
                    patch_output.append(output_value)

                output.append(torch.tensor(patch_output, dtype=torch.float32))

        output = torch.stack(output).view(batch_size, -1, height // 2, width // 2)
        return output.to(x.device)


class QCNN(nn.Module):
    def __init__(self):
        super(QCNN, self).__init__()

        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, stride=1, padding=1)
        self.qconv1 = QuantumConvLayer()

        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        self.qconv2 = QuantumConvLayer()

        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.fc1 = nn.Linear(32 * 7 * 7, 128)
        self.dropout = nn.Dropout(0.3)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.qconv1(x)
        x = self.pool(x)

        x = F.relu(self.conv2(x))
        x = self.qconv2(x)
        x = self.pool(x)

        x = x.view(x.size(0), -1)  # Flatten
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)
