#pragma comment(lib, "ws2_32.lib")
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <stdio.h>
#include <malloc.h>

int main() {
    char buf[1024], file[60];
    SOCKET s, cli_socket;
    int k;
    FILE* source;
    struct sockaddr_in addr, client_addr;
    int len = sizeof(addr);
    char* pBuf = (char*)malloc(1025);

    printf("����������...\n");

    WSAData wsaData;
    if (WSAStartup(WINSOCK_VERSION, &wsaData) != 0) return 0;

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("��ȡSOCKET��ʧ��!!!");
        return 0;
    }

    memset(&addr, 0, len);
    addr.sin_addr.S_un.S_addr = INADDR_ANY;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5100);

    if (bind(s, (struct sockaddr*)&addr, len) < 0) {
        printf("���ܽ���������ַ����SOCKET���ϣ�����");
        closesocket(s);
        return 0;
    }

    if (listen(s, 5) < 0) {
        printf("server:listen");
        return 0;
    }

    while (TRUE) {
        printf("\n--------------------------\n");
        if ((cli_socket = accept(s, (struct sockaddr*)&client_addr, &len)) < 0) {
            printf("server:accept");
            continue;
        }

        int ret = recv(cli_socket, file, sizeof(file), 0);
        if (ret == SOCKET_ERROR) {
            printf("recv��%d\n", WSAGetLastError());
            closesocket(cli_socket);
            continue;
        }

        char client_ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &(client_addr.sin_addr), client_ip, INET_ADDRSTRLEN);
        printf("�ͻ���%s \n�����ļ�%s\n", client_ip, file);

        if (fopen_s(&source, file, "rb") != 0) {
            printf("Ŀ���ļ�%s�����ڻ��ʧ��\n", file);
            closesocket(cli_socket);
            continue;
        }

        while (!feof(source)) {
            k = fread(pBuf, 1, 1024, source);
            if (k <= 0)
                break;
            send(cli_socket, pBuf, k, 0);
            memset(pBuf, '\0', 1025);
        }

        printf("\n�������!!!\n\n");

        fclose(source);
        closesocket(cli_socket);
    }

    free(pBuf);
    closesocket(s);
    WSACleanup();

    return 1;
}
