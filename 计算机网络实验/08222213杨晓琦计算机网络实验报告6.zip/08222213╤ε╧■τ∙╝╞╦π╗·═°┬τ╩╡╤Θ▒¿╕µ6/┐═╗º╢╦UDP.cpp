#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>  
#include <windows.h>

#pragma comment(lib, "ws2_32.lib")

#define SERVER_PORT 8412
#define BUFF_LEN 512
#define DESTINATION_IP "192.168.1.24"

using namespace std;

void send_udp_message(SOCKET socket_fd, struct sockaddr* dest_addr)
{
    int addr_len = sizeof(struct sockaddr_in);
    struct sockaddr_in server_addr;
    int bytes_sent, bytes_received;
    char buffer[BUFF_LEN];

    while (true) {
        cout << "������Ϣ���͵���������:";
        cin.getline(buffer, BUFF_LEN);


        bytes_sent = sendto(socket_fd, buffer, strlen(buffer), 0, dest_addr, sizeof(*dest_addr));
        if (bytes_sent == SOCKET_ERROR) {
            cout << "sendto ����ʧ��: " << WSAGetLastError() << endl;
            break;
        }


        memset(buffer, 0, BUFF_LEN);
        bytes_received = recvfrom(socket_fd, buffer, BUFF_LEN, 0, (struct sockaddr*)&server_addr, &addr_len);
        if (bytes_received == SOCKET_ERROR) {
            cout << "recvfrom ����ʧ��: " << WSAGetLastError() << endl;
            break;
        }


        if (bytes_received > 0) {
            cout << "��������Ӧ: " << buffer << endl << endl;
        }
        else {
            cout << "δ�յ���Ӧ. ���������ܲ�����!" << endl;
        }
    }
}

int main(int argc, char* argv[])
{
    WSADATA wsaData;
    SOCKET client_socket;
    struct sockaddr_in server_address;


    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cout << "WSAStartup ��ʼ��ʧ��: " << WSAGetLastError() << endl;
        return 1;
    }


    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket == INVALID_SOCKET) {
        cout << "�����׽���ʧ��: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }


    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVER_PORT);


    if (inet_pton(AF_INET, DESTINATION_IP, &server_address.sin_addr) <= 0) {
        cout << "��Ч�ĵ�ַ���ַ����֧��" << endl;
        closesocket(client_socket);
        WSACleanup();
        return 1;
    }


    send_udp_message(client_socket, (struct sockaddr*)&server_address);


    closesocket(client_socket);
    WSACleanup();

    return 0;
}

