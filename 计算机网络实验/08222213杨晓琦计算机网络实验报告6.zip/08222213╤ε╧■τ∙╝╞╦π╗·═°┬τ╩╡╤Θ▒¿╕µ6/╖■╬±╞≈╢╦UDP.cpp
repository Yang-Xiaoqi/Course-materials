#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

#define SERVER_PORT 8412
#define BUFF_LEN 512

using namespace std;

void receive_udp_messages(SOCKET socket_fd)
{
    char buffer[BUFF_LEN];
    struct sockaddr_in client_address;
    int buffer_len;
    int bytes_received;
    int client_address_len = sizeof(client_address);

    while (true) {
        cout << "�ȴ��ͻ�����Ӧ..." << endl;
        memset(buffer, 0, BUFF_LEN);
        buffer_len = client_address_len;
        bytes_received = recvfrom(socket_fd, buffer, BUFF_LEN, 0, (struct sockaddr*)&client_address, &buffer_len);

        if (bytes_received == SOCKET_ERROR) {
            cout << "recvfrom ����ʧ��: " << WSAGetLastError() << endl;
            return;
        }

        cout << "�յ��ͻ�����Ϣ: " << buffer << endl;

        memset(buffer, 0, BUFF_LEN);
        strcpy_s(buffer, "���յ�");
        cout << "����ȷ����Ϣ���յ�" << endl << endl;

        sendto(socket_fd, buffer, strlen(buffer), 0, (struct sockaddr*)&client_address, buffer_len);
    }
}

int main(int argc, char* argv[])
{
    WSADATA wsaData;
    SOCKET server_socket;
    struct sockaddr_in server_address;
    int bind_result;

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cout << "WSAStartup ��ʼ��ʧ��: " << WSAGetLastError() << endl;
        return -1;
    }

    server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket == INVALID_SOCKET) {
        cout << "�����׽���ʧ��: " << WSAGetLastError() << endl;
        WSACleanup();
        return -1;
    }

    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(SERVER_PORT);

    bind_result=bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address));
    if (bind_result == SOCKET_ERROR) {
        cout << "���׽���ʧ��: " << WSAGetLastError() << endl;
        closesocket(server_socket);
        WSACleanup();
        return -1;
    }

    receive_udp_messages(server_socket);

    closesocket(server_socket);
    WSACleanup();

    return 0;
}

